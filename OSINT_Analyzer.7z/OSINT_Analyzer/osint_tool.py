import whois
import dns.resolver
import requests
import socket
import ssl
import json
import base64
import dns.query
import dns.zone
import dns.exception

# Define your VirusTotal API key here
VIRUSTOTAL_API_KEY = '7cb73887290e5adabc7b83f951c64d68ca6663f5b51a55882827d5db210615ab'

# Function to perform WHOIS lookup
def whois_lookup(domain):
    print(f"\nPerforming WHOIS lookup for {domain}...")
    try:
        w = whois.whois(domain)
        print(f"WHOIS Information for {domain}:\n{w}")
    except Exception as e:
        print(f"Error in WHOIS lookup: {e}")

# Function to perform DNS Lookup (A Record)
def dns_lookup(domain):
    print(f"\nPerforming DNS lookups for {domain}...\n")

    record_types = ['A', 'AAAA', 'MX', 'NS', 'CNAME', 'TXT', 'SOA']

    for rtype in record_types:
        try:
            answers = dns.resolver.resolve(domain, rtype)
            print(f"{rtype} Records:")
            for rdata in answers:
                print(f" - {rdata.to_text()}")
        except dns.resolver.NoAnswer:
            print(f"No {rtype} record found.")
        except dns.resolver.NXDOMAIN:
            print(f"{domain} does not exist.")
        except Exception as e:
            print(f"Error retrieving {rtype} record: {e}")
        print()

    # Attempt AXFR zone transfer to see if it’s blocked
    try:
        print("Attempting AXFR zone transfer (for info disclosure check)...")
        ns_records = dns.resolver.resolve(domain, 'NS')
        for ns in ns_records:
            ns_target = str(ns.target).rstrip(".")
            try:
                zone = dns.zone.from_xfr(dns.query.xfr(ns_target, domain, timeout=5))
                print(f"AXFR zone transfer SUCCESSFUL from {ns_target}! (This is a vulnerability)")
                print(f"Zone contents from {ns_target}:")
                for name, node in zone.nodes.items():
                    rdatasets = node.rdatasets
                    for rdataset in rdatasets:
                        print(f"{name} {rdataset}")
                break  # if one NS allows it, no need to continue
            except Exception:
                print(f"AXFR zone transfer blocked by {ns_target}")
    except Exception as e:
        print(f"Error during AXFR check: {e}")

# Function to perform IP geolocation lookup using a free API
def ip_geolocation(ip):
    print(f"\nPerforming geolocation for IP: {ip}...")
    try:
        response = requests.get(f"https://ipinfo.io/{ip}/json")
        if response.status_code == 200:
            data = response.json()
            print(f"Geolocation data for {ip}:")
            print(data)
        else:
            print(f"Error in geolocation lookup: {response.status_code}")
    except Exception as e:
        print(f"Error in IP geolocation: {e}")

# Function to search for subdomains using crt.sh
def subdomain_enumeration(domain):
    print(f"\nSearching for subdomains of {domain} using crt.sh...")
    try:
        url = f"https://crt.sh/?q=%25.{domain}&output=json"
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            subdomains = set()
            for entry in data:
                name_values = entry.get("name_value", "")
                for name in name_values.splitlines():
                    name = name.strip()
                    if name.endswith(domain):
                        subdomains.add(name)
            if subdomains:
                print(f"Found subdomains for {domain}:")
                for sub in sorted(subdomains):
                    print(f"- {sub}")
            else:
                print("No subdomains found in CRT.sh certificates.")
        else:
            print(f"Error while fetching subdomains: HTTP {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Network error during subdomain enumeration: {e}")
    except Exception as e:
        print(f"Error in subdomain enumeration: {e}")
        
# Function to get social media links related to a domain
def social_media_search(domain):
    print(f"\nSearching for social media profiles related to {domain}...")
    try:
        search_query = f"{domain} social media"
        search_url = f"https://www.google.com/search?q={search_query}"
        print(f"Google search URL: {search_url}")
    except Exception as e:
        print(f"Error in social media search: {e}")

# Function to retrieve SSL certificate information
import errno

def ssl_certificate_info(domain):
    print(f"\nFetching SSL certificate info for {domain}...")
    try:
        # Resolve domain to IP and test port 443 connectivity first
        socket.setdefaulttimeout(5)
        test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = test_sock.connect_ex((domain, 443))
        test_sock.close()

        if result != 0:
            print(f"Port 443 is closed or unreachable on {domain}. SSL may not be supported.")
            return

        # Proceed with SSL certificate fetch
        context = ssl.create_default_context()
        with context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=domain) as conn:
            conn.settimeout(5)
            conn.connect((domain, 443))
            ssl_info = conn.getpeercert()

        print(f"SSL Certificate Information for {domain}:")
        for key, value in ssl_info.items():
            print(f"{key}: {value}")

    except socket.timeout:
        print(f"Connection to {domain} timed out while fetching SSL certificate.")
    except socket.gaierror as e:
        print(f"DNS resolution error: {e}")
    except ssl.SSLError as e:
        print(f"SSL error while fetching certificate: {e}")
    except socket.error as e:
        if e.errno == errno.ECONNREFUSED:
            print(f"Connection refused on port 443 for {domain}.")
        else:
            print(f"Socket error while connecting to {domain}: {e}")
    except Exception as e:
        print(f"Error in SSL certificate lookup: {e}")

# Function to scan URL with VirusTotal
def virustotal_scan(url):
    print(f"\nPerforming VirusTotal URL scan for {url}...")
    try:
        # Encode the URL in base64 format (without trailing '=' padding)
        encoded_url = base64.urlsafe_b64encode(url.encode()).decode().strip("=")

        headers = {
            'x-apikey': VIRUSTOTAL_API_KEY
        }

        api_url = f"https://www.virustotal.com/api/v3/urls/{encoded_url}"
        response = requests.get(api_url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if 'data' in data:
                scan_results = data['data']['attributes']['last_analysis_stats']
                print(f"VirusTotal scan results for {url}:")
                print(scan_results)
            else:
                print("Error retrieving scan results.")
        else:
            print(f"Error in VirusTotal scan: HTTP {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error in VirusTotal URL scan: {e}")
        

def check_axfr(domain):
    print("\nAttempting AXFR zone transfer (for info disclosure check)...")
    try:
        # Step 1: Get NS records for the domain
        ns_answers = dns.resolver.resolve(domain, 'NS')
        ns_servers = [ns.to_text() for ns in ns_answers]

        print(f"Found NS records: {', '.join(ns_servers)}")
        
        for ns in ns_servers:
            print(f"Trying AXFR with nameserver: {ns}")
            try:
                zone = dns.zone.from_xfr(dns.query.xfr(ns, domain, timeout=5))
                names = zone.nodes.keys()
                print(f"Zone Transfer successful from {ns}. Records:")
                for n in names:
                    print(zone[n].to_text(n))
                return  # Success, no need to continue
            except dns.exception.FormError:
                print(f"AXFR refused by {ns} (standard for production DNS).")
            except Exception as ex:
                print(f"Error attempting AXFR with {ns}: {ex}")

        print("AXFR check complete. No zone transfer allowed.")

    except dns.resolver.NoAnswer:
        print(f"No NS records found for {domain}. Cannot perform AXFR.")
    except dns.resolver.NXDOMAIN:
        print(f"Domain {domain} does not exist.")
    except Exception as e:
        print(f"Error during AXFR check: {e}")


# Main function to integrate the different OSINT modules
def main():
    domain = input("Enter a domain name (e.g., example.com): ").strip()

    # Perform WHOIS lookup
    whois_lookup(domain)

    # Perform DNS lookup
    dns_lookup(domain)

    # Get IP address and perform geolocation lookup
    try:
        ip_address = socket.gethostbyname(domain)
        ip_geolocation(ip_address)
    except Exception as e:
        print(f"Error in resolving IP address: {e}")

    # Perform subdomain enumeration
    subdomain_enumeration(domain)

    # Perform social media search (Google search for simplicity)
    social_media_search(domain)

    # Perform SSL certificate info retrieval
    ssl_certificate_info(domain)

    # Scan the domain URL on VirusTotal
    virustotal_scan(domain)

if __name__ == "__main__":
    main()
